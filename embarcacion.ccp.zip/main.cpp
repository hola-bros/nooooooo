#include "Embarcacion.h"

Embarcacion::Embarcacion(string n, string t, int c, double l, int a) {
    nombre = n;
    tipo = t;
    capacidad = c;
    longitud = l;
    anioFabricacion = a;
    cout << "Embarcación " << nombre << " creada." << endl;
}

Embarcacion::~Embarcacion() {
    cout << "Embarcación " << nombre << " destruida." << endl;
}

void Embarcacion::mostrarDatos() {
    cout << "\n--- Datos de la Embarcación ---" << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Tipo: " << tipo << endl;
    cout << "Capacidad: " << capacidad << " personas" << endl;
    cout << "Longitud: " << longitud << " metros" << endl;
    cout << "Año de fabricación: " << anioFabricacion << endl;
}

void Embarcacion::encenderMotores() {
    cout << "Encendiendo motores de " << nombre << "..." << endl;
}

void Embarcacion::detenerMotores() {
    cout << "Motores de " << nombre << " detenidos." << endl;
}
