#include "Velero.h"

Velero::Velero(string n, int c, double l, int a, int v, string m)
    : Embarcacion(n, "Velero", c, l, a) {
    numVelas = v;
    materialMastil = m;
    cout << "Velero " << nombre << " creado." << endl;
}

Velero::~Velero() {
    cout << "Velero " << nombre << " destruido." << endl;
}

void Velero::mostrar() {
    mostrarDatos();
    cout << "Número de velas: " << numVelas << endl;
    cout << "Material del mástil: " << materialMastil << endl;
}

void Velero::izarVelas() {
    cout << nombre << " ha izado sus velas." << endl;
}

void Velero::bajarVelas() {
    cout << nombre << " ha bajado sus velas." << endl;
}
