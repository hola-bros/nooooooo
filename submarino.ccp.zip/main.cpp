#include "Submarino.h"

Submarino::Submarino(string n, int c, double l, int a, int p, int t)
    : Embarcacion(n, "Submarino", c, l, a) {
    profundidadMax = p;
    tripulantes = t;
    cout << "Submarino " << nombre << " creado." << endl;
}

Submarino::~Submarino() {
    cout << "Submarino " << nombre << " destruido." << endl;
}

void Submarino::mostrar() {
    mostrarDatos();
    cout << "Profundidad máxima: " << profundidadMax << " m" << endl;
    cout << "Tripulantes: " << tripulantes << endl;
}

void Submarino::sumergir() {
    cout << nombre << " se está sumergiendo..." << endl;
}

void Submarino::emerger() {
    cout << nombre << " está emergiendo a la superficie." << endl;
}
