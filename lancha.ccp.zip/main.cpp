#include "Lancha.h"

Lancha::Lancha(string n, int c, double l, int a, int p, double comb)
    : Embarcacion(n, "Lancha", c, l, a) {
    potenciaMotor = p;
    combustible = comb;
    cout << "Lancha " << nombre << " creada." << endl;
}

Lancha::~Lancha() {
    cout << "Lancha " << nombre << " destruida." << endl;
}

void Lancha::mostrar() {
    mostrarDatos();
    cout << "Potencia del motor: " << potenciaMotor << " HP" << endl;
    cout << "Combustible actual: " << combustible << " litros" << endl;
}

void Lancha::acelerar() {
    if (combustible > 0) {
        cout << nombre << " está acelerando..." << endl;
        combustible -= 5;
    } else {
        cout << "Sin combustible para acelerar." << endl;
    }
}

void Lancha::repostarCombustible(double litros) {
    combustible += litros;
    cout << nombre << " ha repostado " << litros << " litros. Total: " << combustible << " litros." << endl;
}
